﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactElec.CapaEntidad.RegistroComprobante
{
    public class En_DocumentoSustentoNota
    {
        public string CodigoMotivoAnulacion { get; set; }
        public string SerieNumero { get; set; }

        public string MotivoAnulacion { get; set; }
    }
}
