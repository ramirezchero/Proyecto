﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactElec.CapaEntidad.RegistroComprobante
{
    public class En_DocumentoReferenciaNota

    {
        public string SerieNumero { get; set; }
        public string Fecha { get; set; }
        public string TipoDocumento { get; set; }
    }
}
