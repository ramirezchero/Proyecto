﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Configuration;

namespace FactElec.AccesoDatos
{

    /// <summary>
    /// SQL Database Manager
    /// </summary>
    /// 

    public class ADConexionBD {
        public string fstrConexion() {
            string cadenaSql = ConfigurationManager.ConnectionStrings["conexSql"].ConnectionString;
            var connectionString = cadenaSql; //string.Format("Data Source={0};Initial Catalog={1};User ID={2};Password={3};Connect TimeOut=500000;", oENConfigXml.Servidor, oENConfigXml.BaseDatos, oENConfigXml.Usuario, oENConfigXml.Contrasenia);

            return connectionString;
        }
    }

    public sealed partial class SqlHelper
    {
        public static SqlConnection fcn_ObtenerConexion()
        {
            ADConexionBD oADConexionBD = new ADConexionBD();
            SqlConnection Conexion = new SqlConnection(oADConexionBD.fstrConexion());
            return Conexion;
        }

        public SqlConnection fcn_ObtenerConexionTransaccion()
        {
            ADConexionBD oADConexionBD = new ADConexionBD();
            SqlConnection Conexion = new SqlConnection(oADConexionBD.fstrConexion());
            return Conexion;
        }

       
        public static int ExecuteNonQuery(string spName, SqlCommand cmd)
        {
            SqlConnection cn;
            cn = fcn_ObtenerConexion();

            if (cmd == null)
                cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandText = spName;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandTimeout = 120;
            try
            {
                cn.Open();
                return cmd.ExecuteNonQuery();
            }
            catch (Exception x)
            {
                //Log.Error(x.Message, excepcion: x);
                throw new System.Exception(x.Message);
            }
            finally
            {
                if (cn.State == ConnectionState.Open)
                {
                    cn.Close();
                    cn.Dispose();
                    cn = null/* TODO Change to default(_) if this is not a reference type */;
                }
                cmd.Dispose();
                cmd = null/* TODO Change to default(_) if this is not a reference type */;
            }
        }

        public static int ExecuteNonQuery(SqlConnection oConx, string spName, SqlCommand cmd, SqlTransaction oTr)
        {
            if (cmd == null)
                cmd = new SqlCommand();
            cmd.Connection = oConx;
            cmd.CommandText = spName;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Transaction = oTr;
            cmd.CommandTimeout = 120;
            try
            {
                return cmd.ExecuteNonQuery();
            }
            catch (Exception x)
            {
               // Log.Error(x.Message, excepcion: x);
                throw new System.Exception(x.Message);
            }
            finally
            {
                cmd.Dispose();
                cmd = null/* TODO Change to default(_) if this is not a reference type */;
            }
        }

        



        public static string ExecuteScalar(string spName, SqlCommand cmd)
        {
            SqlConnection cn;
            object strUltValor;

            cn = fcn_ObtenerConexion();

            if (cmd == null)
                cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandText = spName;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandTimeout = 120;
            try
            {
                cn.Open();
                strUltValor = cmd.ExecuteScalar();

                string strResultado = "";

                if (strUltValor == System.DBNull.Value)
                    strResultado = "";
                else if (strUltValor == null)
                    strResultado = "";
                else
                    strResultado = System.Convert.ToString(strUltValor);

                return strResultado;
            }
            catch (Exception ex)
            {
               // Log.Error(ex.Message, excepcion: ex);
                throw new System.Exception(ex.Message);
            }
            finally
            {
                if (cn.State == ConnectionState.Open)
                {
                    cn.Close(); cn.Dispose(); cn = null/* TODO Change to default(_) if this is not a reference type */;
                }
                cmd.Dispose(); cmd = null/* TODO Change to default(_) if this is not a reference type */;
            }
        }



        public static DataTable FillDataTable(string spName, SqlCommand cmd)
        {
            SqlConnection cn;
            cn = fcn_ObtenerConexion();

            if (cmd == null)
                cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandText = spName;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandTimeout = 120;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();

            try
            {
                cn.Open();
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                //Log.Error(spName + " " + ex.Message, excepcion: ex);
                return null/* TODO Change to default(_) if this is not a reference type */;
            }
            finally
            {
                if (cn.State == ConnectionState.Open)
                {
                    cn.Close(); cn.Dispose(); cn = null/* TODO Change to default(_) if this is not a reference type */;
                }
                cmd.Dispose(); cmd = null/* TODO Change to default(_) if this is not a reference type */;
                da.Dispose(); da = null/* TODO Change to default(_) if this is not a reference type */;
            }
        }

        public static DataSet FillDataSet(string spName, SqlCommand cmd)
        {
            SqlConnection cn;
            cn = fcn_ObtenerConexion();

            if (cmd == null)
                cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandText = spName;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandTimeout = 120;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ods = new DataSet();

            try
            {
                cn.Open();
                da.Fill(ods);
                return ods;
            }
            catch (Exception ex)
            {
                //Log.Error(ex.Message, excepcion: ex);
                throw new System.Exception(ex.Message);
            }
            finally
            {
                if (cn.State == ConnectionState.Open)
                {
                    cn.Close(); cn.Dispose(); cn = null/* TODO Change to default(_) if this is not a reference type */;
                }
                cmd.Dispose(); cmd = null/* TODO Change to default(_) if this is not a reference type */;
                da.Dispose(); da = null/* TODO Change to default(_) if this is not a reference type */;
            }
        }

       

        
        public new static SqlDataReader ExecuteReader(string spName, SqlCommand cmd)
        {
            SqlConnection cn;
            cn = fcn_ObtenerConexion();

            if (cmd == null)
                cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandText = spName;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandTimeout = 120;
            SqlDataReader dr;

            try
            {
                cn.Open();
                dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
            }
            // dr.Close()
            catch (Exception ex)
            {
                //Log.Error(ex.Message, excepcion: ex);
                throw new Exception(ex.Message);
            }
            finally
            {
                cmd.Dispose(); cmd = null/* TODO Change to default(_) if this is not a reference type */;
            }

            return dr;
        }
    }

}
